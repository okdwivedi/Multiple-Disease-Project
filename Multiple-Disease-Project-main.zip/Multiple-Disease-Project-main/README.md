# Multiple-Disease-Project
Analyse the relevant health data of the users using Machine Learning Algorithms and provide accurate disease predictions
